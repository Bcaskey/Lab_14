//Logic for page actions here. 

var controllers = angular.module('', []);

controllers.controller('', []);