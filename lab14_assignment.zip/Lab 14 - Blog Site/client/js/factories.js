//The action to call the local API should be here

var app = angular.module('', ['']);
app.factory('', ['', []]);


