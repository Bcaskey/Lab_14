//Use to instantiate app, connect factory & controllers and configure app.

var app = angular.module('', []);

app.config([]);